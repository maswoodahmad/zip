import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { tap, Observable, throwError, filter, map, switchMap ,catchError} from 'rxjs';
import { IProduct } from '../Data/product.model';

@Injectable({
  providedIn: 'root',
})
export class productApiService {
  url: string = 'api/products';
  constructor(private http: HttpClient) {}

  // get list of Products
  getProducts(): Observable<IProduct[]> {
    return this.http
      .get<IProduct[]>(this.url)
      .pipe(tap((data) => console.log(`Products : ${JSON.stringify(data)}`)));
  }

  addproduct(product: IProduct) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http
      .post(this.url, product,{headers})
      .pipe(tap((data) => console.log(`Data is been added ${data}`)),catchError(this.handleError));
  }

  getSingleproduct(id: number): Observable<IProduct> {
    return this.http
    .get<IProduct>(`${this.url}/${id}`)
    .pipe(tap((data) => console.log(`Products : ${JSON.stringify(data)}`)),catchError(this.handleError));
  }

  // deleteproduct(id: number): Observable<Iproduct> {
  //   return this.http.get<Iproduct[]>(this.url).pipe(
  //     switchMap((allProducts) => {
  //       const productToDelete = allProducts.find((product) => product.id === id);
  //       if (!productToDelete) {
  //         throw new Error('product Not Found');
  //       } else {
  //         return this.http
  //           .delete(`${this.url}/${id}`)
  //           .pipe(map(() => productToDelete));
  //       }
  //     })
  //   );
  // }
  deleteproduct(id : number){
    return this.http.delete(`${this.url}/${id}`).pipe(
      tap((data)=>console.log(data)),catchError(this.handleError)
    )
  }

  updateproduct(updatedproduct: IProduct) {
    return this.http
      .put(`${this.url}/${updatedproduct.id}`, updatedproduct)
      .pipe(tap((data) => console.log(`Data is been added ${data}`)),catchError(this.handleError));
  }
   handleError(err: HttpErrorResponse): Observable<never> {
    let errorMessage = '';

    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.

      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.

      // The response body may contain clues as to what went wrong,

      errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
    }

    console.error(errorMessage);

    return throwError(() => errorMessage);
  }
}
