import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanDeactivate,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';
import { CityAddComponent } from './product-add/product-add.component';

@Injectable({
  providedIn: 'root',
})
export class ProductFormGuard implements CanDeactivate<ProductAddComponent> {
  canDeactivate(
    component: ProductAddComponent,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    if (!component.formSubmitted) {
      const productName = component.newProduct.name;

      return confirm(
        `Would you like to navigate away and lose all the changes to ${productName}`
      );
    }

    return true;
  }
}

// import { InjectDecorator, inject } from '@angular/core';

// import { CanDeactivateFn, Router } from '@angular/router';
// import { CityAddComponent } from './city-add/city-add.component';

// export const canAccessGuard: CanDeactivateFn(CityAddComponent) = (route, state) => {

// };
