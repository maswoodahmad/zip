import { AlertsService } from 'angular-alert-module';
import { Component, OnInit } from '@angular/core';
import { Product, IProduct } from 'src/app/Data/product.model';
import { ProductApiService } from 'src/app/services/product-api.service';
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
})
export class ProductListComponent {
  title: string = 'List of Cities';
  products: IProduct[] = [];
  selectedProduct: string | undefined;
  errMessage = '';
  constructor(
    public productService: ProductApiService,
    public alerts: AlertsService
  ) {}

  message: string = 'None';
  handleOnRatingClicked(event: string) {
    // alert(event);
    this.message = event;
  }

  getSelected(product: IProduct) {
    this.selectedProduct = product.name;
  }
  deleteProduct(id: number) {
    this.productService.deleteProduct(id).subscribe({
      next: (data) => {
        console.log(data);
        this.products = this.products.filter((product) => product.id !== id);
      },
      complete: () => {
        console.log('Data Deleted Successfully');
        this.alerts.setMessage(
          `Product with id ${id} deleted successfully `,
          'success'
        );
      },
    });
  }

  ngOnInit() {
    this.productService.getCities().subscribe({
      next: (data) => (this.products = data),
      error: (err) => this.productService.handleError(err),
      complete: () => console.log('Data Received Successfully'),
    });
  }
 


  
}
