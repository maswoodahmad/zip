import { AlertsModule } from 'angular-alert-module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListComponent } from './product-list/product-list.component';
// import { SharedModule } from '../shared/shared.module';
// import { ProductDetailsComponent } from './product-details/product-details.component';
import { Route, RouterModule } from '@angular/router';
import { MaterialModule } from '../material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SharedModule } from "../shared/shared.module";
import {MatToolbarModule} from '@angular/material/toolbar'


const routes: Route[] = [];
@NgModule({
    declarations: [
        
        
        ProductListComponent,
        ProductAddComponent,
    ],
    imports: [
        CommonModule,
        MaterialModule,
        // SharedModule,
        RouterModule.forChild(routes),
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        AlertsModule.forRoot(),
        SharedModule,
        MatToolbarModule
    ],
    exports: [
        ProductListComponent,
        ProductFormGuard],
})
export class CitiesModule {}
