import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ProductListComponent } from './products/product-list/product-list.component';
import { Error404Component } from './error404.component';
// import { ProductDetailsComponent } from './products/product-details/product-details.component';
import { ProductAddComponent } from './products/product-add/product-add.component';
// import { ProductEditComponent } from './products/product-edit/product-edit.component';
import { RxjsDemoComponent } from './shared/rxjsDemo.component';
// import { canAccessGuard } from './products/product-edit/edit-guard.guard';
import { ProductFormGuard } from './products/product-form.guard';

const routes: Routes = [
  { path: 'home', component: HomeComponent, pathMatch: 'full' },
  { path: 'rxjs', component: RxjsDemoComponent, pathMatch: 'full' },
  { path: 'products', component: ProductListComponent, pathMatch: 'full' },
  { path: 'products/add',canDeactivate:[ProductFormGuard], component: ProductAddComponent, pathMatch: 'full' },
  // { path: 'products/edit/:id',canActivate : [canAccessGuard], component: ProductEditComponent, pathMatch: 'full'},
  // { path: 'products/:id', component: ProductDetailsComponent, pathMatch: 'full' },
  { path: 'index', redirectTo: 'home', pathMatch: 'full' },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: '**', component: Error404Component },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
